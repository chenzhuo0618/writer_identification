function X=unMarshal(X,size)

X=X(1:size(1),1:size(2),1:size(3));
end

